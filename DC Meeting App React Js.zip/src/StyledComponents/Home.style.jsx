
export const ButtonStyle2 = {
    background:'#009975',
    color: '#FFFFFF',
    fontSize: '14px',
    lineHeight: '18px',
    fontWeight: '500',
    border:'1px solid #009975',
    margin:'4px',
    height:'fit-content',
  };

// export const ButtonStyle = {
//     background:'#d1e2e8',
//     color: '#3C4043',
//     border:'none',
//     fontSize: '14px',
//     lineHeight: '18px',
//     fontWeight: '500',
//   };
export const AddTag = {
    background:'#F0F4F9',
    color: '#3C4043',
    border:'none',
    fontSize: '12px',
    fontWeight: '500',
    padding: '2px 4px',
  };